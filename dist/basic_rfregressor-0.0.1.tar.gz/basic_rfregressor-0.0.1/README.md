This is a simple regression problem solved using RandomForestRegressor

Before using the module of this packe make sure your data has no missing values and unimportant columns are removed from the data like id,date,zipcode etc.

## To excute the script
First install the dependencies specified in env.yml file.
Now open the cmd prompt and type the below command
python < scriptname.py >
